Free Profit Margin Mini Calculator
SadeekShop — free version

How to use
1. Check the settings (currency, default VAT %, default target margin %).
2. Type up to 10 products in the yellow cells: cost, shipping/packaging, platform fee % and fixed fee.
3. The sheet calculates the suggested selling price including VAT, and compares it with your own price if you enter one.

This is a free 10-product edition. The full version (Arabic, English and Finnish, unlimited products, reports and charts) is available at SadeekShop:
https://sadeekkasem.github.io/sadeekshop/#profit-margin-pricing

For personal use. Redistribution or resale is not allowed.
